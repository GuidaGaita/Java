package exercícios;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		Medico medico = new Medico();
		medico.setFuncao("anestesista");
		medico.setNome("Cleber");
		medico.setIdade(45);
		medico.setCpf(111111);
		
		Paciente paciente = new Paciente();
		paciente.setCondicao("asmático");
		paciente.setNome("Roberta");
		paciente.setIdade(25);
		paciente.setCpf(321231313);
		
		
		
		int i = 0 ;
		
		while (i != -1) {
			int choice = 0;
			System.out.println("=-=-=MENU=-=-=");
			System.out.println("1 - informaçoes do médico");
			System.out.println("2 - adicionar paciente");
			System.out.println("3 - Remover paciente");
			System.out.println("4 imprimir pacientes");
			System.out.println("=-=-=-=-=-=");
			System.out.println("=-=-=MENU=-=-=");
			System.out.println("5 - informaçoes do paciente");
			System.out.println("6 - Adicionar exame");
			System.out.println("7 - Listar exames");
			System.out.println("8 - sair");
			choice = sc.nextInt();
		
		
		switch (choice) {
		case 1:
			System.out.println("Nome: "+ medico.getNome());
			System.out.println("Funçao: " + medico.getFuncao());
			System.out.println("Idade: " +medico.getIdade());
			System.out.println("CPF: "+ medico.getCpf());
			break;
			
		 case 2:
			medico.addPaciente();
			System.out.println("Paciente adicionado");
			break;
			
		 case 3: 
			 String p = sc.next();
			 medico.removePaciente(p);
			 System.out.println("Paciente Removido");
			 break;
			 
		 case 4: 
			 medico.imprimirPacientes();
			 break;
		 case 5:
			 System.out.println("Nome: "+ paciente.getNome());
			 System.out.println("Idade: "+ paciente.getIdade());
			 System.out.println("CPF: " +paciente.getCpf());
			 System.out.println("Condiçao: " +paciente.getCondicao());
			 break;
		 case 6:
			 paciente.adicionarExame();
			 System.out.println("Exame adicionado");
			 break;
		 case 7:
			 paciente.imprimirLista();
			 break;
		 case 8:
			 i = -1;
			 break;
			 
			 
			 

			}
		
		
		}
		
		
		
	}
}
