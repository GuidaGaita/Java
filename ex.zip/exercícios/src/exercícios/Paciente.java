package exercícios;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Paciente extends Pessoa {
		Scanner sc = new Scanner(System.in);
		private String condicao;
		public List <String> listaExames = new ArrayList <> ();

		public String getCondicao() {
			return condicao;
		}

		public void setCondicao(String condicao) {
			this.condicao = condicao;
		}
		
		public void adicionarExame() {
			String exame = sc.nextLine();
			listaExames.add(exame);
		}	
		
		public void imprimirLista() {
			for (String exame : listaExames) {
				System.out.println(exame);
			}
		}

		
		
		
		
		}
		


