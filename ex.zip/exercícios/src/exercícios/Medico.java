package exercícios;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class Medico extends Pessoa {
	
	Scanner sc = new Scanner(System.in);
	
	private String funcao;
	private List <String> pacientes = new ArrayList <> ();

	public String getFuncao() {
		return funcao;
	}

	public void setFuncao(String funcao) {
		this.funcao = funcao;
	}
	
	
	public void addPaciente() {
		 String element = sc.nextLine();
		pacientes.add(element);
	}

	public void removePaciente (String element) {
		pacientes.remove(element);
	}
	
	
	public void imprimirPacientes() {
		for (String Element : pacientes) {
			System.out.println(Element);
		}
	}
	
	
	
}
