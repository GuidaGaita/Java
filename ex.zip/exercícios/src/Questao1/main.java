package Questao1;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner (System.in);
		
		Aluno aluno = new Aluno();
	
		System.out.println("informe o nome:");
		String Nome = sc.next();
		
		System.out.println("informe a nota A:");
		int nota1 = sc.nextInt();
		aluno.setNota1(nota1);
		
		System.out.println("informe a nota A:");
		int nota2 = sc.nextInt();
		aluno.setNota2(nota2);
		
		aluno.calcMedia(nota1, nota2);
		
		
		
	}

}
