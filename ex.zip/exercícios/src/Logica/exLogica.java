package Logica;

import java.util.Scanner;

public class exLogica {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		//QUESTAO 01 -=-=-=-=-=-=-=-=-=-=
		int larguraA = 300;
		int comprimentoA = 230;
		
		int larguraB = 300;
		int comprimentoB = 230;
		
		int areaA = larguraA * comprimentoA;
		int areaB = larguraB * comprimentoB;
		
		if (areaA > areaB) {
			System.out.println("a maior área é: "+ areaA);
		} else if (areaB > areaA) {
			System.out.println("a maior área é: "+ areaB);

		} else {
			System.out.println("as areas são iguais");
		}
		
		
		
		//QUESTAO 02
		System.out.println("chute um numero (2018 para encerrar o loop)");

		
		
		int contador = 0;
		int palpite = 0;
		
		
		while (palpite != 2018) {
			palpite = sc.nextInt();
			if (palpite == 2018) {
				System.out.println("Cino chutou :"+ contador +" vezes até acertar o número 2018");
				break;
			}
			
			
			contador++;
		}
	
		
		//QUESTAO 03 
		
	// VERDADEIRA = V B P B (EXEMPLO DE NUMERO: 5393)
	// FALSA = V P B V (EXEMPLO DE NUMERO : 3953}	
		int n1 = 3;
		int n2 = 2;
		int n3 = 1;
		int n4 = 3;
		
		if (n1 == n4 && n2 != n1) {
			System.out.println("o padrao de numeros:"+ n1+", " +n2+", "+n3+", "+ n4+" equivale as cores de uma coral FALSA");
		} else if (n2 == n4 && n1 != n3) {
			System.out.println("o padrao de numeros:"+ n1+", "+n2+", "+n3+", "+ n4+" equivale as cores de uma coral VERDADEIRA");

		} else {
			System.out.println("esse padrao numerico"+ n1+", " +n2+", "+n3+", "+ n4+   " nao corresponde as cores da cobra coral");
		}
		
		
		//QUESTAO 04
		
		
		int linha = 0;
		int coluna = 0;
		
		
		
		System.out.println("digite o valor da linha");
		linha = sc.nextInt();
		
		System.out.println("digite o valor da coluna");
		coluna = sc.nextInt();
		
		if ((coluna + linha) % 2 == 0) {
			System.out.println(1);
		} else {
			System.out.println(0);
		}
		
		
		sc.close();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
