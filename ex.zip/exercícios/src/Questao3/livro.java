package Questao3;

import java.util.Scanner;

public class livro extends Autor {
	
	private String titulo;
	private String editora;
	private String sinopse;
	private String autor;
	public String getEditora() {
		return editora;
	}
	public void setEditora(String editora) {
		this.editora = editora;
	}
	public String getSinopse() {
		return sinopse;
	}
	public void setSinopse(String sinopse) {
		this.sinopse = sinopse;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		autor = autor;
	}
	
	public void infoLivro() {
		System.out.println("titulo: "+titulo);
		System.out.println("Autor: "+autor);
		System.out.println("editora: "+editora);
		System.out.println("sinopse: "+sinopse);
		
	}
	
	public void setAutor() {}
	public void setAutor(Autor apostolos) {
		// TODO Auto-generated method stub
		
	}
	

}
