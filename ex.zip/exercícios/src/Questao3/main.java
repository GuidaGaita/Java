package Questao3;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Autor Apostolos = new Autor();
		Apostolos.setNome("Pedro");
		
		
		livro Biblia = new livro();
		Biblia.setAutor(Apostolos);
		Biblia.setSinopse("As aventuras de Jesus cristo");
		Biblia.setEditora("igreja");
		
		
		
		
		
		
		
		
		
		
	}

}
